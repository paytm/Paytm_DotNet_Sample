﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using paytm;

public partial class _Default : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {


    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        Dictionary<string, string> Dict = new Dictionary<string, string>();

        Dict.Add("Chandan", "vinay");
        int len = TextBox1.Text.Length;
        if (len == 16)
        {

            //------GenerateCheckSum 
            string res = CheckSum.generateCheckSum(TextBox1.Text, Dict);

            //------verifyCheckSum function check value
            Boolean res1 = CheckSum.verifyCheckSum(TextBox1.Text, Dict, res);

              Response.Write("Value is : " + res);;


            
            
        }
        else {
            Response.Write("String Should be 16 digit");
        }
    }
}